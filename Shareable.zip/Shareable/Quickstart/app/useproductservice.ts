import {Component} from '@angular/core';
import {ProductService} from './product.service';

@Component({
    selector:'productclient',
    template:`    
    <h1> Product Service Client </h1>
    <div style="width:500px;border:2px solid red;border-radius:10px;padding:20px;margin:20px;">
     <input type="text" [(ngModel)]="productToBeAdded" /> {{productReceived}}  <br/><br/>
    <input type="button" (click)="AddProduct()" value="Add Product>>" class="btn btn-primary" />
    <input type="button" (click)="GetProduct()" value="Get Random Product" class="btn btn-danger" />    
</div> `//, providers:[ProductService]
})
export class UseProductServiceComponent{
    productToBeAdded:string="";    productReceived:string="";
        constructor(private serviceObj:ProductService){ } //DI
        AddProduct(){
            this.serviceObj.insertNewProduct(this.productToBeAdded);
        }    
        GetProduct(){
          this.productReceived =   this.serviceObj.getRandomProduct();
        }
    }