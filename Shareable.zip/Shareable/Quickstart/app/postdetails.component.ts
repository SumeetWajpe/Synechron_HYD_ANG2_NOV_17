import {Component} from '@angular/core';
import {ActivatedRoute} from '@angular/router';

@Component({
    selector:'post',
    template:`    
    <h1> Post details for {{postId}} </h1>

  `
})
export class PostDetailsComponent{
 
        postId:number;
        constructor(private route:ActivatedRoute){
            this.route.params.subscribe(p => this.postId = p["id"])
        }       
       
    }