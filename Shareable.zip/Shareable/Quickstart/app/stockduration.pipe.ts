import {Pipe,PipeTransform} from '@angular/core';

@Pipe({
    name:'stockduration'
})
export class StockDuration implements PipeTransform {
        transform(inputvalue:string,...args:string[]){
            console.log(args)
                return inputvalue + args[0];
        }
}