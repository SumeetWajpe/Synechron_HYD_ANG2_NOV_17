"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ProductComponent = (function () {
    function ProductComponent() {
        this.prodDetails = {};
        this.isFree = true;
        this.styleToBeApplied = { backgroundColor: 'green', border: '2px solid red' };
        this.classToBeApplied = "Product BorderedClass";
        this.productToBeSearched = "";
    }
    return ProductComponent;
}());
__decorate([
    core_1.Input('pDetails'),
    __metadata("design:type", Object)
], ProductComponent.prototype, "prodDetails", void 0);
ProductComponent = __decorate([
    core_1.Component({
        selector: 'product',
        template: "\n\n    <!-- <input type=\"text\" [(ngModel)]=\"productToBeSearched\" />\n        <div  [ngSwitch]=\"productToBeSearched\" >\n        <p *ngSwitchCase=\"'Laptop'\" > Laptop </p>\n        <p *ngSwitchCase=\"'TV'\"> TV </p>\n        <p *ngSwitchCase=\"'Mobile'\"> Mobile </p>\n        <p *ngSwitchCase=\"'Camera'\"> Camera </p>\n        <p *ngSwitchDefault> No Product With Such Name ! </p>\n        \n        \n        </div> -->\n\n\n\n\n\n\n\n    <div [ngClass]=\"{'Product':true,'BorderedClass':true}\">\n    <h1> {{prodDetails.name  | uppercase | lowercase   }} </h1>\n                    <img [src]=\"prodDetails.ImageUrl\" height=\"100px\" width=\"100px\" /> <br/>\n      \n               Is Free ?      <input type=\"checkbox\" [(ngModel)]=\"isFree\" />\n\n                    <!-- <div [style.backgroundColor]=\"isFree ? 'green' : 'red' \"  > -->\n              <div [ngStyle]=\"styleToBeApplied\" >                    \n                    <b> Price :  </b> {{prodDetails.price | currency:'INR':true }} <br/>\n                    </div><br/>\n                    <b> Quantity :  </b> {{prodDetails.quantity}} <br/>\n                    <b> Stock Lasts :  </b> {{prodDetails.stockLasts | stockduration:' Days':' Year' }} <br/>\n                    \n                    <b> Rating :  </b> {{prodDetails.rating | number:'1.1-2'    }} <br/> \n                    <b> Raw Data : </b> {{ prodDetails | json }}\n        </div>  ",
        styleUrls: ['./app/product.styles.css']
        //         styles:[
        // `
        // .Product{       
        //     border:2px solid black;
        //     background-color: lightgreen;
        //     border-radius:10px;
        //     padding:20px;
        //     margin:20px;
        //   }
        // `
        //         ]
    })
], ProductComponent);
exports.ProductComponent = ProductComponent;
//# sourceMappingURL=product.component.js.map