import {Component} from '@angular/core';
import {IProduct} from './IProduct';

@Component({
    selector: 'shoppingcart',    
    templateUrl:'./app/shoppingcart.component.html',
    // template:`
    //     <h1> {{shoppingcartDetails.heading}} </h1>

    //                 <div  *ngFor="let p of products">
    //                     <product [pDetails]="p" ></product>
    //                 </div>   
    // `,
    styles:[`
    
    input.ng-pristine.ng-invalid{
        background-color:pink;
    }

    input.ng-dirty.ng-valid{
        background-color:lightgreen;
    }

    input.ng-dirty.ng-invalid{
       border:2px solid red;
    }
    
    
    
    
    
    
    `]
       
})
export class ShoppingCartComponent {       

    productToBeSearched:string = "";
    newProduct:any = {};
    shoppingcartDetails:any ={
        heading:'Flipkart',
        saleDate:new Date()
    }
    
    products:any[] = [

        {name: 'Laptop', stockLasts:2, price: 50000, quantity: 100, rating: 4 ,ImageUrl:'https://rukminim1.flixcart.com/image/704/704/j431rbk0/computer/t/h/p/hp-notebook-original-imaev2zfjqfpf3ng.jpeg?q=70' },
        { name: 'LED TV',stockLasts:4, price: 25000, quantity: 10, rating: 3.5674,ImageUrl:'http://www.lg.com/in/images/tvs/md05602497/gallery/Large-940x620.jpg'},
        { name: 'Desktop',stockLasts:6, price: 10000, quantity: 200, rating: 3,ImageUrl:'https://images-eu.ssl-images-amazon.com/images/I/41IjXCFmiRL._SL500_AC_SS350_.jpg'  },
        { name: 'Mobile',stockLasts:5, price: 20000, quantity: 1000, rating: 5,ImageUrl:'https://assets.mspcdn.net/t_c-desktop-normal,f_auto,q_auto,d_c:noimage.jpg/c/8808-62-4.jpg'  },
        { name: 'Camera',stockLasts:2, price: 90000, quantity: 10, rating: 4,ImageUrl:'https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_left.png'}
       
    ];

    ChangeHeadingHandler():void{
        this.shoppingcartDetails.heading = "Amazon";
    }

    KeyUpEventHandler(evt:any):void{
      //  console.log(evt.target);
            this.shoppingcartDetails.heading = evt.target.value;
    }

    onFormSubmit(theForm:any){
        // add the new Product to products collection !
        let productToBeAdded = {
            name:this.newProduct.name,
            quantity:this.newProduct.quantity,
            price:this.newProduct.price,
            date:this.newProduct.date            
        }

        if(theForm.valid){
            this.products.push(productToBeAdded);
            //this.newProduct = {};           
           theForm.reset();
        }

       
    }

   

}