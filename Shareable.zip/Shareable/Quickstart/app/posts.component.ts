import {Component} from '@angular/core';
import {PostsService} from './posts.service';

@Component({
    selector:'post',
    template:`    
    <h1> Posts </h1>

    <div>
    <ul>
        <li *ngFor="let p of postsData">
       <a routerLink="/post/{{p.id}}">    {{p.title}}   </a>
        </li>
    </ul>
</div>

  `, 
  providers:[PostsService]
})
export class PostsComponent{
    postsData:any[] = [];
        constructor(private serviceObj:PostsService){
          let aPromise =      this.serviceObj.getPosts();// use the service
          aPromise.then((response)=>{
              this.postsData = response.json();
          },(err)=>{
                console.log('Error : ' + err)
          })
         } //DI
       
    }