import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import{HttpModule} from '@angular/http';
import {RouterModule,RouterOutlet,Route} from '@angular/router';

import { AppComponent }  from './app.component';
import {CourseComponent} from './course.component';
import  {ShoppingCartComponent} from './shoppingcart.component';
import {ProductComponent} from './product.component';
import {PostsComponent} from './posts.component';
import {PostDetailsComponent} from './postdetails.component';


import {UseProductServiceComponent} from './useproductservice';

import {StockDuration} from './stockduration.pipe';
import {ProductService} from './product.service';


const routes:Route[]=[
  {path:'posts',component:PostsComponent},
  {path:'cart',component:ShoppingCartComponent}  ,
  {path:'post/:id',component:PostDetailsComponent}  
  
]


@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(routes) ],
  declarations: [ AppComponent,PostDetailsComponent,PostsComponent,UseProductServiceComponent,StockDuration,CourseComponent,ShoppingCartComponent,ProductComponent ],
  bootstrap:    [ AppComponent ],
  providers:[ProductService]
})
export class AppModule { }
