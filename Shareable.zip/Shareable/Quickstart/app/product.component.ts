import {Component,Input} from '@angular/core';

@Component({
    selector:'product',    
    template:`

    <!-- <input type="text" [(ngModel)]="productToBeSearched" />
        <div  [ngSwitch]="productToBeSearched" >
        <p *ngSwitchCase="'Laptop'" > Laptop </p>
        <p *ngSwitchCase="'TV'"> TV </p>
        <p *ngSwitchCase="'Mobile'"> Mobile </p>
        <p *ngSwitchCase="'Camera'"> Camera </p>
        <p *ngSwitchDefault> No Product With Such Name ! </p>
        
        
        </div> -->







    <div [ngClass]="{'Product':true,'BorderedClass':true}">
    <h1> {{prodDetails.name  | uppercase | lowercase   }} </h1>
                    <img [src]="prodDetails.ImageUrl" height="100px" width="100px" /> <br/>
      
               Is Free ?      <input type="checkbox" [(ngModel)]="isFree" />

                    <!-- <div [style.backgroundColor]="isFree ? 'green' : 'red' "  > -->
              <div [ngStyle]="styleToBeApplied" >                    
                    <b> Price :  </b> {{prodDetails.price | currency:'INR':true }} <br/>
                    </div><br/>
                    <b> Quantity :  </b> {{prodDetails.quantity}} <br/>
                    <b> Stock Lasts :  </b> {{prodDetails.stockLasts | stockduration:' Days':' Year' }} <br/>
                    
                    <b> Rating :  </b> {{prodDetails.rating | number:'1.1-2'    }} <br/> 
                    <b> Raw Data : </b> {{ prodDetails | json }}
        </div>  ` ,
        styleUrls:['./app/product.styles.css']
//         styles:[
// `
// .Product{       
//     border:2px solid black;
//     background-color: lightgreen;
//     border-radius:10px;
//     padding:20px;
//     margin:20px;
//   }
// `
//         ]
            
})
export class ProductComponent{
 @Input('pDetails')   prodDetails:any={};
 isFree:boolean = true;
 styleToBeApplied:any = {backgroundColor:'green',border:'2px solid red'};
 classToBeApplied:string = "Product BorderedClass";
 productToBeSearched:string= "";

}