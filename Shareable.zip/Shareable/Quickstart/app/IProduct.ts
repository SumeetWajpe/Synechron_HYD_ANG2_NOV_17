export interface IProduct{
    name:string;
    price:number;
    quantity:number;
    rating:number;
    ImageUrl:string;
    stockLasts:number;
}
