import {Component,Input} from '@angular/core';

@Component({    
    selector:'course',
    template:`<h2>   {{coursedetails.name}} </h2>    
                        <b>Duration : </b>  {{coursedetails.duration}} <br/>
                        <b>Price : </b>  {{coursedetails.price}} <hr/>
                        
    <!-- <img src="{{ImageUrl}}" height="200px" width="200px" />
    <img [src]="ImageUrl" height="200px" width="200px" /> -->
    
    `
}) 

export class CourseComponent{
        
    @Input('name')    coursedetails:any = {name: "Angular 2.0",price:4000,duration:'3 Days'};
    ImageUrl:string = 'https://pbs.twimg.com/profile_images/593402183246221313/vQv9AxqM.png';
}

