import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template:`
  

  <a routerLink="/posts" class="btn btn-primary">  POSTS </a>
  <a routerLink="/cart" class="btn btn-primary">  Shopping Cart </a>
  

  <router-outlet></router-outlet>
  
  `
  // template:`
  // <post></post>
  // `
  // template:`
  // <productclient></productclient>
  // <productclient></productclient>`
  //template:`<shoppingcart></shoppingcart>`
  // template: `
  
  // <h1> Training Details </h1>
  
  //  <!-- <course name="{{course1}}"></course>
  // <course name="{{course2}}"></course> -->

  //  <course [name]="course1"></course>
  // <course [name]="course2"></course> 
  // <course></course> 
  
  // `
})
export class AppComponent  { 
  name = 'Angular'; 
  course1:any = {name: "ReactJS",price:5000,duration:'3 Days'};
  course2:any = {name:'NodeJS',price:3000,duration:'3 Days'};
  
}
